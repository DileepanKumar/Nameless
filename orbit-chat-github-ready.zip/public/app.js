const state = {
  mode: null,
  token: null,
  roomId: null,
  expiresAt: null,
  username: null,
  socket: null
};

const $ = (id) => document.getElementById(id);

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));
  $(id).classList.remove('hidden');
}

function showError(id, message) {
  $(id).textContent = message || '';
}

function toast(message) {
  const el = $('toast');
  el.textContent = message;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2800);
}

function formatExpiry(date) {
  const ms = new Date(date) - Date.now();
  if (ms <= 0) return 'Expired';
  const days = Math.floor(ms / 86400000);
  const hours = Math.floor((ms % 86400000) / 3600000);
  return days > 0 ? `Expires in ${days}d ${hours}h` : `Expires in ${hours}h`;
}

$('create-btn').onclick = () => {
  state.mode = 'create';
  $('credentials-title').textContent = 'CREATE ROOM';
  $('credentials-submit').textContent = 'CREATE ROOM';
  $('room-id').value = '';
  $('room-password').value = '';
  showError('credentials-error', '');
  showScreen('credentials-screen');
};

$('enter-btn').onclick = () => {
  state.mode = 'enter';
  $('credentials-title').textContent = 'ENTER ROOM';
  $('credentials-submit').textContent = 'ENTER ROOM';
  $('room-id').value = '';
  $('room-password').value = '';
  showError('credentials-error', '');
  showScreen('credentials-screen');
};

$('back-home').onclick = () => showScreen('home-screen');

$('credentials-form').onsubmit = async (event) => {
  event.preventDefault();
  showError('credentials-error', '');

  const roomId = $('room-id').value.trim();
  const password = $('room-password').value;

  try {
    const endpoint = state.mode === 'create' ? '/api/rooms' : '/api/rooms/join';
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ roomId, password })
    });
    const data = await response.json();

    if (!response.ok) {
      showError('credentials-error', data.error || 'Something went wrong.');
      return;
    }

    state.token = data.token;
    state.roomId = data.roomId;
    state.expiresAt = data.expiresAt;
    state.pendingMessages = data.messages || [];

    $('username').value = '';
    showError('username-error', '');
    showScreen('username-screen');
  } catch {
    showError('credentials-error', 'Cannot connect to the server.');
  }
};

$('username-form').onsubmit = (event) => {
  event.preventDefault();
  const username = $('username').value.trim();

  if (!username || username.length > 24 || /[<>]/.test(username)) {
    showError('username-error', 'Username must be 1–24 characters.');
    return;
  }

  state.username = username;
  openChat();
};

function openChat() {
  $('chat-room-name').textContent = `ROOM: ${state.roomId}`;
  $('expiry-label').textContent = formatExpiry(state.expiresAt);
  $('messages').innerHTML = '';

  for (const message of state.pendingMessages || []) {
    renderMessage(message);
  }

  state.pendingMessages = [];

  state.socket = io({
    auth: { token: state.token }
  });

  state.socket.on('connect', () => {
    state.socket.emit('join-chat', { username: state.username });
    $('message-input').focus();
  });

  state.socket.on('connect_error', (error) => {
    toast(error.message || 'Connection failed.');
  });

  state.socket.on('message', renderMessage);
  state.socket.on('system', renderSystem);
  state.socket.on('room-expired', () => {
    toast('This room has expired and was destroyed.');
    leaveRoom();
  });

  showScreen('chat-screen');
}

function renderMessage(message) {
  const wrapper = document.createElement('article');
  wrapper.className = `message ${message.username === state.username ? 'mine' : ''}`;

  const meta = document.createElement('div');
  meta.className = 'meta';
  meta.textContent = `${message.username} · ${new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

  const body = document.createElement('div');
  body.className = 'body';
  body.textContent = message.text;

  wrapper.append(meta, body);
  $('messages').appendChild(wrapper);
  $('messages').scrollTop = $('messages').scrollHeight;
}

function renderSystem(text) {
  const item = document.createElement('div');
  item.className = 'system';
  item.textContent = text;
  $('messages').appendChild(item);
  $('messages').scrollTop = $('messages').scrollHeight;
}

$('message-form').onsubmit = (event) => {
  event.preventDefault();
  const input = $('message-input');
  const text = input.value.trim();
  if (!text || !state.socket?.connected) return;

  state.socket.emit('send-message', { text });
  input.value = '';
};

$('leave-btn').onclick = leaveRoom;

function leaveRoom() {
  if (state.socket) state.socket.disconnect();
  state.socket = null;
  state.token = null;
  state.roomId = null;
  state.expiresAt = null;
  state.username = null;
  showScreen('home-screen');
}

setInterval(() => {
  if (!state.expiresAt || $('chat-screen').classList.contains('hidden')) return;
  $('expiry-label').textContent = formatExpiry(state.expiresAt);
}, 60000);
